let api_key = "25986140e0d34941636f99dbf6f5310e";

let img_url = "https://image.tmdb.org/t/p/w500";
let original_img_url = "https://image.tmdb.org/t/p/original";
let genres_list_http = "https://api.themoviedb.org/3/genre/movie/list?";
let movie_genres_http = "https://api.themoviedb.org/3/discover/movie?";
let movie_detail_http = "https://api.themoviedb.org/3/movie";